function [Qprod] = QuaternionProduct(Q1, Q2)
% This function computes the quaterion product of two quaternions Q1 and Q2
% Q1 and Q2 must be N-by-4 matrices (N: # of observations)

% See the following link for more details:
% https://en.wikipedia.org/wiki/Quaternion

Qprod(:,1) = Q1(:,1).*Q2(:,1) - Q1(:,2).*Q2(:,2) ...
    - Q1(:,3).*Q2(:,3) - Q1(:,4).*Q2(:,4);

Qprod(:,2) = Q1(:,1).*Q2(:,2) + Q1(:,2).*Q2(:,1) ...
    + Q1(:,3).*Q2(:,4) - Q1(:,4).*Q2(:,3);

Qprod(:,3) = Q1(:,1).*Q2(:,3) - Q1(:,2).*Q2(:,4) ...
    + Q1(:,3).*Q2(:,1) + Q1(:,4).*Q2(:,2);

Qprod(:,4) = Q1(:,1).*Q2(:,4) + Q1(:,2).*Q2(:,3) ...
    - Q1(:,3).*Q2(:,2) + Q1(:,4).*Q2(:,1);
end
