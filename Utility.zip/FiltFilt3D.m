function  Data = FiltFilt3D(b, a, Data)
% FiltFilt3D Exactly same function as filtfilt but works on 3D data
%     filtered = filtfilt3D(b,a,rawData) applies the function filtfilt
%     separately on each of the three columns of rawData.
Data(:,1) = filtfilt(b, a, Data(:,1));
Data(:,2) = filtfilt(b, a, Data(:,2));
Data(:,3) = filtfilt(b, a, Data(:,3));

end