function [QConj] = QuaternionConjugate(Q)
% This function returns the quaternion conjugate of Q
% Q must be N-by-4 matrices (N: # of observations)

% See the following link for more details:
% https://en.wikipedia.org/wiki/Quaternion

QConj = [Q(:,1) -Q(:,2) -Q(:,3) -Q(:,4)];
end
