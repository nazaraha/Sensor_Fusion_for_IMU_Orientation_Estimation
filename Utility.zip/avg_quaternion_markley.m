function [Qavg] = avg_quaternion_markley(Q)
% by Tolga Birdal
% Q is an Mx4 matrix of quaternions. Qavg is the average quaternion
% Based on
% Markley, F. Landis, Yang Cheng, John Lucas Crassidis, and Yaakov Oshman.
% "Averaging quaternions." Journal of Guidance, Control, and Dynamics 30, no. 4 (2007): 1193-1197.

% Cite As
% Tolga Birdal (2020). tolgabirdal/averaging_quaternions (https://github.com/tolgabirdal/averaging_quaternions), GitHub. Retrieved December 31, 2020.

% See: https://www.mathworks.com/matlabcentral/fileexchange/40098-tolgabirdal-averaging_quaternions


% Form the symmetric accumulator matrix
A = zeros(4,4);
M = size(Q,1);

for i=1:M
    q = Q(i,:)';
    A = q*q'+A; % rank 1 update
end

% scale
A=(1.0/M)*A;

% Get the eigenvector corresponding to largest eigen value
[Qavg, ~] = eigs(A,1);

end