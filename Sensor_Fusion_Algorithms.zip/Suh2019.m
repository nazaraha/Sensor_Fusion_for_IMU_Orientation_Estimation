classdef Suh2019 < handle
% Suh, Y.S. Simple-Structured Quaternion Estimator Separating Inertial and Magnetic Sensor Effects. 
% IEEE, Transactions on Aerospace and Electronic Systems 2019, 55, 2698�2706.
%
% Implemented by Justa

    %% Public properties
    properties (Access = public)
        SamplePeriod = 1/100;
        Quaternion = [1 0 0 0];     % output quaternion describing the Earth relative to the sensor
        
        q_err=[0 0 0];
        
        rg=0.317;
        ra=0.0004156;%0.0056;
        rm=0.00057;%0.001
        
        g = 1; % gravitational acceleration
        dip_angle = 75;  % Dip Angle in Edmonton
        alf=0;
        bet=0;
        gam=0;
        
        kAlf=0;
        kBet=0;
               
        test=[0 0 0 0];
        test2=[0 0 0 0];
    end

    %% Public methods
    methods (Access = public)
        function obj = Suh2019(varargin)
            for i = 1:2:nargin
                if  strcmp(varargin{i}, 'SamplePeriod'), obj.SamplePeriod = varargin{i+1};
                elseif  strcmp(varargin{i}, 'Quaternion'), obj.Quaternion = varargin{i+1};
%                 elseif  strcmp(varargin{i}, 'Beta'), obj.Beta = varargin{i+1};
%                 elseif  strcmp(varargin{i}, 'alf'), obj.alf = varargin{i+1};
                end
            end
        end
        function obj = Update(obj, Gyroscope, Accelerometer, Magnetometer)
            dt=obj.SamplePeriod;
            q=obj.Quaternion;

            q_dif_est=0.5*quaternProd(q,[0 Gyroscope(1) Gyroscope(2) Gyroscope(3)]);            
            q_est=q+q_dif_est*dt;
                        
            AccNorm=Accelerometer./norm(Accelerometer);
            Magnetometer=Magnetometer./norm(Magnetometer);

            cosAccMag=sind(obj.dip_angle);%dot(AccNorm,Magnetometer);
            sinAccMag=sqrt(1-cosAccMag^2);
            sinDipAng=cosAccMag;
            cosDipAng=sinAccMag;
            
            ak_minus=obj.alf+obj.rg*dt^2/4;
            bk_minus=obj.bet+obj.rm*dt^2/4;
            
            obj.kAlf=2*ak_minus*obj.g/(4*ak_minus*obj.g^2+obj.ra);
            obj.kBet=-2*(bk_minus*cosDipAng-4*obj.gam*sinDipAng)/...
                (4*ak_minus*sinDipAng^2+4*bk_minus*cosDipAng^2-8*obj.gam*cosDipAng*sinDipAng+obj.rm);
            
            obj.alf=(4*ak_minus*obj.g^2+obj.ra)*obj.kAlf^2-4*ak_minus*obj.g*obj.kAlf+ak_minus;
            obj.bet=(4*ak_minus*sinDipAng^2+4*bk_minus*cosDipAng^2+obj.rm-8*obj.gam*cosDipAng*sinDipAng)*obj.kBet^2 ...
                        +4*(bk_minus*cosDipAng-4*obj.gam*sinDipAng)*obj.kBet+bk_minus;    
            obj.gam=-(2*obj.g*obj.kAlf-1)*(obj.gam+2*(obj.gam*cosDipAng-ak_minus*sinDipAng)*obj.kBet);

            aRot=quaternProd(q_est,quaternProd([0 AccNorm],quaternConj(q_est)));
            z1=(aRot(2:4)-[0 0 obj.g]);
            z1=z1(1:2)';
            
            mRot=quaternProd(q_est,quaternProd([0 Magnetometer],quaternConj(q_est)));
            z2=mRot(3);
            
            K=[0 obj.kAlf 0; -obj.kAlf 0 0; 0 0 obj.kBet];
            H=[0 -1 0; 1 0 0; sinDipAng, 0 -cosDipAng]*2;
            obj.q_err=obj.q_err+(K*([z1;z2]-H*obj.q_err'))';
            
%             obj.q_err=[0 0 0];
            obj.test = [z1;z2;0]';
            obj.test2 = [aRot(2:4) 0];

            normQ=[1 obj.q_err]/norm([1 obj.q_err]);
            q=quaternProd(normQ, q_est);

            obj.Quaternion = q / norm(q); % normalise quaternion
        end
    end
end

function ab = quaternProd(a, b)
%QUATERNPROD Calculates the quaternion product
%
%   ab = quaternProd(a, b)
%
%   Calculates the quaternion product of quaternion a and b.
%
%   For more information see:
%   http://www.x-io.co.uk/node/8#quaternions
%
%	Date          Author          Notes
%	27/09/2011    SOH Madgwick    Initial release
%      ab=[1,0,0,0];

    ab=zeros(length(a(:,1)),4);

    ab(:,1) = a(:,1).*b(:,1)-a(:,2).*b(:,2)-a(:,3).*b(:,3)-a(:,4).*b(:,4);
    ab(:,2) = a(:,1).*b(:,2)+a(:,2).*b(:,1)+a(:,3).*b(:,4)-a(:,4).*b(:,3);
    ab(:,3) = a(:,1).*b(:,3)-a(:,2).*b(:,4)+a(:,3).*b(:,1)+a(:,4).*b(:,2);
    ab(:,4) = a(:,1).*b(:,4)+a(:,2).*b(:,3)-a(:,3).*b(:,2)+a(:,4).*b(:,1);
end

function quat_c=quaternConj(q)

quat_c=[q(:,1),-q(:,2),-q(:,3),-q(:,4)];
end